import React, { useState, useEffect } from 'react';
import { DollarSign, TrendingUp, Calendar, PiggyBank } from 'lucide-react';
import IncomeBalance from './components/IncomeBalance';
import WeeklyExpenseTracker from './components/WeeklyExpenseTracker';
import ExpenseTracker from './components/ExpenseTracker';
import CumulativeSavingsTracker from './components/CumulativeSavingsTracker';

export interface BudgetData {
  budgeted: number;
  actual: number;
}

export interface WeeklyData {
  week1: number;
  week2: number;
  week3: number;
  week4: number;
}

export interface WeeklyBudgetData {
  budgeted: number;
  actual: WeeklyData;
}

function App() {
  const [income, setIncome] = useState({
    salary: 0,
    otherIncome: 0,
  });

  const [groceries, setGroceries] = useState<WeeklyBudgetData>({
    budgeted: 0,
    actual: { week1: 0, week2: 0, week3: 0, week4: 0 },
  });

  const [diningOut, setDiningOut] = useState<WeeklyBudgetData>({
    budgeted: 0,
    actual: { week1: 0, week2: 0, week3: 0, week4: 0 },
  });

  const [investments, setInvestments] = useState<BudgetData>({
    budgeted: 0,
    actual: 0,
  });

  const [subscriptions, setSubscriptions] = useState<BudgetData>({
    budgeted: 0,
    actual: 0,
  });

  const [miscellaneous, setMiscellaneous] = useState<BudgetData>({
    budgeted: 0,
    actual: 0,
  });

  const [savings, setSavings] = useState<BudgetData>({
    budgeted: 0,
    actual: 0,
  });

  const [currentMonth, setCurrentMonth] = useState(new Date().toISOString().slice(0, 7));

  const totalIncome = income.salary + income.otherIncome;
  
  const totalExpenses = 
    (groceries.actual.week1 + groceries.actual.week2 + groceries.actual.week3 + groceries.actual.week4) +
    (diningOut.actual.week1 + diningOut.actual.week2 + diningOut.actual.week3 + diningOut.actual.week4) +
    subscriptions.actual +
    miscellaneous.actual;

  const totalInvestmentsSavings = investments.actual + savings.actual;
  
  const endOfMonthBalance = totalIncome - totalExpenses - totalInvestmentsSavings;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <PiggyBank className="w-10 h-10 text-indigo-600 mr-3" />
            <h1 className="text-4xl font-bold text-gray-800">Monthly Budget Planner</h1>
          </div>
          <p className="text-gray-600 text-lg">Track your finances with precision and style</p>
          
          <div className="flex items-center justify-center mt-4">
            <Calendar className="w-5 h-5 text-indigo-500 mr-2" />
            <input
              type="month"
              value={currentMonth}
              onChange={(e) => setCurrentMonth(e.target.value)}
              className="bg-white border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            />
          </div>
        </div>

        {/* Income and Balance Summary */}
        <IncomeBalance
          income={income}
          setIncome={setIncome}
          totalIncome={totalIncome}
          totalExpenses={totalExpenses}
          totalInvestmentsSavings={totalInvestmentsSavings}
          endOfMonthBalance={endOfMonthBalance}
        />

        {/* Weekly Expense Trackers */}
        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          <WeeklyExpenseTracker
            title="Groceries"
            icon={<DollarSign className="w-6 h-6" />}
            data={groceries}
            setData={setGroceries}
            colorScheme="green"
          />
          <WeeklyExpenseTracker
            title="Dining Out / Takeout"
            icon={<TrendingUp className="w-6 h-6" />}
            data={diningOut}
            setData={setDiningOut}
            colorScheme="orange"
          />
        </div>

        {/* Other Expense Trackers */}
        <div className="grid lg:grid-cols-2 xl:grid-cols-4 gap-6 mb-8">
          <ExpenseTracker
            title="Investments"
            icon={<TrendingUp className="w-6 h-6" />}
            data={investments}
            setData={setInvestments}
            colorScheme="purple"
          />
          <ExpenseTracker
            title="Subscriptions"
            icon={<DollarSign className="w-6 h-6" />}
            data={subscriptions}
            setData={setSubscriptions}
            colorScheme="blue"
          />
          <ExpenseTracker
            title="Miscellaneous"
            icon={<DollarSign className="w-6 h-6" />}
            data={miscellaneous}
            setData={setMiscellaneous}
            colorScheme="gray"
          />
          <ExpenseTracker
            title="Savings"
            icon={<PiggyBank className="w-6 h-6" />}
            data={savings}
            setData={setSavings}
            colorScheme="green"
          />
        </div>

        {/* Cumulative Savings Tracker */}
        <CumulativeSavingsTracker
          currentMonth={currentMonth}
          currentSavings={savings.actual}
        />
      </div>
    </div>
  );
}

export default App;