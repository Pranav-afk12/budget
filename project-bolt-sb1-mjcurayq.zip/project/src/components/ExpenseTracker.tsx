import React from 'react';
import { BudgetData } from '../App';

interface ExpenseTrackerProps {
  title: string;
  icon: React.ReactNode;
  data: BudgetData;
  setData: React.Dispatch<React.SetStateAction<BudgetData>>;
  colorScheme: 'green' | 'orange' | 'blue' | 'purple' | 'gray';
}

const ExpenseTracker: React.FC<ExpenseTrackerProps> = ({
  title,
  icon,
  data,
  setData,
  colorScheme,
}) => {
  const colorClasses = {
    green: {
      bg: 'bg-green-100',
      text: 'text-green-600',
      border: 'border-green-200',
      gradient: 'from-green-50 to-emerald-50',
    },
    orange: {
      bg: 'bg-orange-100',
      text: 'text-orange-600',
      border: 'border-orange-200',
      gradient: 'from-orange-50 to-amber-50',
    },
    blue: {
      bg: 'bg-blue-100',
      text: 'text-blue-600',
      border: 'border-blue-200',
      gradient: 'from-blue-50 to-indigo-50',
    },
    purple: {
      bg: 'bg-purple-100',
      text: 'text-purple-600',
      border: 'border-purple-200',
      gradient: 'from-purple-50 to-indigo-50',
    },
    gray: {
      bg: 'bg-gray-100',
      text: 'text-gray-600',
      border: 'border-gray-200',
      gradient: 'from-gray-50 to-slate-50',
    },
  };

  const colors = colorClasses[colorScheme];

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  const difference = data.budgeted - data.actual;

  return (
    <div className={`bg-white rounded-2xl shadow-xl p-6 border ${colors.border}`}>
      <div className="flex items-center mb-6">
        <div className={`${colors.bg} p-3 rounded-xl mr-4`}>
          <div className={colors.text}>{icon}</div>
        </div>
        <h3 className="text-lg font-bold text-gray-800">{title}</h3>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-600 mb-2">
            Budgeted Amount
          </label>
          <input
            type="number"
            value={data.budgeted || ''}
            onChange={(e) => setData(prev => ({ ...prev, budgeted: Number(e.target.value) || 0 }))}
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-200"
            placeholder="Enter budget"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-600 mb-2">
            Actual Amount
          </label>
          <input
            type="number"
            value={data.actual || ''}
            onChange={(e) => setData(prev => ({ ...prev, actual: Number(e.target.value) || 0 }))}
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-200"
            placeholder="Enter actual"
          />
        </div>
      </div>

      <div className={`bg-gradient-to-r ${colors.gradient} p-4 rounded-xl ${colors.border} border mt-6`}>
        <div className="grid grid-cols-3 gap-2 text-center">
          <div>
            <p className="text-xs text-gray-600 mb-1">Budgeted</p>
            <p className="font-bold text-sm">{formatCurrency(data.budgeted)}</p>
          </div>
          <div>
            <p className="text-xs text-gray-600 mb-1">Actual</p>
            <p className="font-bold text-sm">{formatCurrency(data.actual)}</p>
          </div>
          <div>
            <p className="text-xs text-gray-600 mb-1">Difference</p>
            <p className={`font-bold text-sm ${difference >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {difference >= 0 ? '+' : ''}{formatCurrency(difference)}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ExpenseTracker;