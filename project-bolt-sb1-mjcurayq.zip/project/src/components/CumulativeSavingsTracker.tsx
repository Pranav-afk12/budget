import React, { useState, useEffect } from 'react';
import { TrendingUp, Plus, Trash2 } from 'lucide-react';

interface SavingsEntry {
  month: string;
  amount: number;
}

interface CumulativeSavingsTrackerProps {
  currentMonth: string;
  currentSavings: number;
}

const CumulativeSavingsTracker: React.FC<CumulativeSavingsTrackerProps> = ({
  currentMonth,
  currentSavings,
}) => {
  const [savingsHistory, setSavingsHistory] = useState<SavingsEntry[]>(() => {
    const saved = localStorage.getItem('savingsHistory');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('savingsHistory', JSON.stringify(savingsHistory));
  }, [savingsHistory]);

  useEffect(() => {
    // Update current month's savings automatically
    if (currentSavings > 0) {
      setSavingsHistory(prev => {
        const existingIndex = prev.findIndex(entry => entry.month === currentMonth);
        if (existingIndex >= 0) {
          const updated = [...prev];
          updated[existingIndex] = { month: currentMonth, amount: currentSavings };
          return updated;
        } else {
          return [...prev, { month: currentMonth, amount: currentSavings }];
        }
      });
    }
  }, [currentMonth, currentSavings]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  const formatMonth = (monthString: string) => {
    const date = new Date(monthString + '-01');
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'long' });
  };

  const sortedSavings = [...savingsHistory].sort((a, b) => a.month.localeCompare(b.month));
  
  const calculateRunningTotal = (index: number) => {
    return sortedSavings.slice(0, index + 1).reduce((sum, entry) => sum + entry.amount, 0);
  };

  const totalSavings = sortedSavings.reduce((sum, entry) => sum + entry.amount, 0);

  const addManualEntry = () => {
    const month = prompt('Enter month (YYYY-MM format):');
    const amount = prompt('Enter savings amount:');
    
    if (month && amount && /^\d{4}-\d{2}$/.test(month)) {
      const numAmount = parseFloat(amount);
      if (!isNaN(numAmount)) {
        setSavingsHistory(prev => {
          const existingIndex = prev.findIndex(entry => entry.month === month);
          if (existingIndex >= 0) {
            const updated = [...prev];
            updated[existingIndex] = { month, amount: numAmount };
            return updated;
          } else {
            return [...prev, { month, amount: numAmount }];
          }
        });
      }
    }
  };

  const removeEntry = (month: string) => {
    setSavingsHistory(prev => prev.filter(entry => entry.month !== month));
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          <div className="bg-green-100 p-3 rounded-xl mr-4">
            <TrendingUp className="w-8 h-8 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-800">Cumulative Savings Tracker</h2>
        </div>
        <button
          onClick={addManualEntry}
          className="flex items-center bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition-colors duration-200"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Entry
        </button>
      </div>

      {/* Total Savings Summary */}
      <div className="bg-gradient-to-r from-green-100 to-emerald-100 p-6 rounded-xl border border-green-200 mb-6">
        <div className="text-center">
          <h3 className="text-lg font-semibold text-green-700 mb-2">Total Accumulated Savings</h3>
          <p className="text-3xl font-bold text-green-800">{formatCurrency(totalSavings)}</p>
        </div>
      </div>

      {/* Savings History Table */}
      {sortedSavings.length > 0 ? (
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b-2 border-gray-200">
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Month</th>
                <th className="text-right py-3 px-4 font-semibold text-gray-700">Monthly Savings</th>
                <th className="text-right py-3 px-4 font-semibold text-gray-700">Running Total</th>
                <th className="text-center py-3 px-4 font-semibold text-gray-700">Actions</th>
              </tr>
            </thead>
            <tbody>
              {sortedSavings.map((entry, index) => {
                const runningTotal = calculateRunningTotal(index);
                const isCurrentMonth = entry.month === currentMonth;
                
                return (
                  <tr 
                    key={entry.month} 
                    className={`border-b border-gray-100 hover:bg-gray-50 transition-colors duration-200 ${
                      isCurrentMonth ? 'bg-blue-50 border-blue-200' : ''
                    }`}
                  >
                    <td className="py-4 px-4">
                      <div className="flex items-center">
                        {formatMonth(entry.month)}
                        {isCurrentMonth && (
                          <span className="ml-2 bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full">
                            Current
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="py-4 px-4 text-right font-semibold text-green-600">
                      {formatCurrency(entry.amount)}
                    </td>
                    <td className="py-4 px-4 text-right font-bold text-gray-800">
                      {formatCurrency(runningTotal)}
                    </td>
                    <td className="py-4 px-4 text-center">
                      {!isCurrentMonth && (
                        <button
                          onClick={() => removeEntry(entry.month)}
                          className="text-red-500 hover:text-red-700 transition-colors duration-200"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="text-center py-12">
          <div className="text-gray-400 mb-4">
            <TrendingUp className="w-16 h-16 mx-auto" />
          </div>
          <p className="text-gray-600 text-lg">No savings history yet</p>
          <p className="text-gray-500">Start saving this month to see your progress!</p>
        </div>
      )}
    </div>
  );
};

export default CumulativeSavingsTracker;