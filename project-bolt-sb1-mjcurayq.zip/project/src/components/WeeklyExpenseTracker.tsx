import React from 'react';
import { WeeklyBudgetData } from '../App';

interface WeeklyExpenseTrackerProps {
  title: string;
  icon: React.ReactNode;
  data: WeeklyBudgetData;
  setData: React.Dispatch<React.SetStateAction<WeeklyBudgetData>>;
  colorScheme: 'green' | 'orange' | 'blue' | 'purple';
}

const WeeklyExpenseTracker: React.FC<WeeklyExpenseTrackerProps> = ({
  title,
  icon,
  data,
  setData,
  colorScheme,
}) => {
  const colorClasses = {
    green: {
      bg: 'bg-green-100',
      text: 'text-green-600',
      border: 'border-green-200',
      gradient: 'from-green-50 to-emerald-50',
    },
    orange: {
      bg: 'bg-orange-100',
      text: 'text-orange-600',
      border: 'border-orange-200',
      gradient: 'from-orange-50 to-amber-50',
    },
    blue: {
      bg: 'bg-blue-100',
      text: 'text-blue-600',
      border: 'border-blue-200',
      gradient: 'from-blue-50 to-indigo-50',
    },
    purple: {
      bg: 'bg-purple-100',
      text: 'text-purple-600',
      border: 'border-purple-200',
      gradient: 'from-purple-50 to-indigo-50',
    },
  };

  const colors = colorClasses[colorScheme];

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  const totalActual = data.actual.week1 + data.actual.week2 + data.actual.week3 + data.actual.week4;
  const difference = data.budgeted - totalActual;

  const updateWeeklyActual = (week: keyof WeeklyBudgetData['actual'], value: number) => {
    setData(prev => ({
      ...prev,
      actual: {
        ...prev.actual,
        [week]: value,
      },
    }));
  };

  return (
    <div className={`bg-white rounded-2xl shadow-xl p-6 border ${colors.border}`}>
      <div className="flex items-center mb-6">
        <div className={`${colors.bg} p-3 rounded-xl mr-4`}>
          <div className={colors.text}>{icon}</div>
        </div>
        <h3 className="text-xl font-bold text-gray-800">{title}</h3>
      </div>

      {/* Budget Input */}
      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-600 mb-2">
          Monthly Budget
        </label>
        <input
          type="number"
          value={data.budgeted || ''}
          onChange={(e) => setData(prev => ({ ...prev, budgeted: Number(e.target.value) || 0 }))}
          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-200"
          placeholder="Enter monthly budget"
        />
      </div>

      {/* Weekly Actual Inputs */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        {(['week1', 'week2', 'week3', 'week4'] as const).map((week, index) => (
          <div key={week}>
            <label className="block text-sm font-medium text-gray-600 mb-2">
              Week {index + 1}
            </label>
            <input
              type="number"
              value={data.actual[week] || ''}
              onChange={(e) => updateWeeklyActual(week, Number(e.target.value) || 0)}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-200"
              placeholder="$0"
            />
          </div>
        ))}
      </div>

      {/* Summary */}
      <div className={`bg-gradient-to-r ${colors.gradient} p-4 rounded-xl ${colors.border} border`}>
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <p className="text-sm text-gray-600 mb-1">Budgeted</p>
            <p className="font-bold text-gray-800">{formatCurrency(data.budgeted)}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600 mb-1">Actual Total</p>
            <p className="font-bold text-gray-800">{formatCurrency(totalActual)}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600 mb-1">Difference</p>
            <p className={`font-bold ${difference >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {difference >= 0 ? '+' : ''}{formatCurrency(difference)}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WeeklyExpenseTracker;