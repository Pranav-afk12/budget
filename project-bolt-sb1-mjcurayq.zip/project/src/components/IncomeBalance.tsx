import React from 'react';
import { DollarSign, TrendingUp, TrendingDown } from 'lucide-react';

interface IncomeBalanceProps {
  income: {
    salary: number;
    otherIncome: number;
  };
  setIncome: React.Dispatch<React.SetStateAction<{
    salary: number;
    otherIncome: number;
  }>>;
  totalIncome: number;
  totalExpenses: number;
  totalInvestmentsSavings: number;
  endOfMonthBalance: number;
}

const IncomeBalance: React.FC<IncomeBalanceProps> = ({
  income,
  setIncome,
  totalIncome,
  totalExpenses,
  totalInvestmentsSavings,
  endOfMonthBalance,
}) => {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl p-8 mb-8 border border-gray-100">
      <div className="flex items-center mb-6">
        <div className="bg-indigo-100 p-3 rounded-xl mr-4">
          <DollarSign className="w-8 h-8 text-indigo-600" />
        </div>
        <h2 className="text-2xl font-bold text-gray-800">Income & Balance Overview</h2>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        {/* Income Input Section */}
        <div className="space-y-6">
          <h3 className="text-lg font-semibold text-gray-700 mb-4">Monthly Income</h3>
          
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-2">
              Salary
            </label>
            <input
              type="number"
              value={income.salary || ''}
              onChange={(e) => setIncome(prev => ({ ...prev, salary: Number(e.target.value) || 0 }))}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-200"
              placeholder="Enter your salary"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-600 mb-2">
              Other Income
            </label>
            <input
              type="number"
              value={income.otherIncome || ''}
              onChange={(e) => setIncome(prev => ({ ...prev, otherIncome: Number(e.target.value) || 0 }))}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-200"
              placeholder="Enter other income"
            />
          </div>
        </div>

        {/* Summary Section */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-gray-700 mb-4">Financial Summary</h3>
          
          <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-4 rounded-xl border border-green-200">
            <div className="flex items-center justify-between">
              <span className="text-green-700 font-medium">Total Income</span>
              <span className="text-green-800 font-bold text-lg">{formatCurrency(totalIncome)}</span>
            </div>
          </div>

          <div className="bg-gradient-to-r from-red-50 to-pink-50 p-4 rounded-xl border border-red-200">
            <div className="flex items-center justify-between">
              <span className="text-red-700 font-medium">Total Expenses</span>
              <span className="text-red-800 font-bold text-lg">{formatCurrency(totalExpenses)}</span>
            </div>
          </div>

          <div className="bg-gradient-to-r from-purple-50 to-indigo-50 p-4 rounded-xl border border-purple-200">
            <div className="flex items-center justify-between">
              <span className="text-purple-700 font-medium">Investments & Savings</span>
              <span className="text-purple-800 font-bold text-lg">{formatCurrency(totalInvestmentsSavings)}</span>
            </div>
          </div>

          <div className={`p-4 rounded-xl border-2 ${
            endOfMonthBalance >= 0 
              ? 'bg-gradient-to-r from-green-100 to-emerald-100 border-green-300' 
              : 'bg-gradient-to-r from-red-100 to-pink-100 border-red-300'
          }`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                {endOfMonthBalance >= 0 ? (
                  <TrendingUp className="w-5 h-5 text-green-600 mr-2" />
                ) : (
                  <TrendingDown className="w-5 h-5 text-red-600 mr-2" />
                )}
                <span className={`font-bold ${endOfMonthBalance >= 0 ? 'text-green-700' : 'text-red-700'}`}>
                  End-of-Month Balance
                </span>
              </div>
              <span className={`font-bold text-xl ${endOfMonthBalance >= 0 ? 'text-green-800' : 'text-red-800'}`}>
                {formatCurrency(endOfMonthBalance)}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default IncomeBalance;